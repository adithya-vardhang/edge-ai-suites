# =============================================================================
# Smart Tolling SceneScape Adapter - SIDE (Side Camera)
# =============================================================================
# Complete standalone adapter for Vehicle/Axle Detection.
# For use with toll-side pipeline.
#
# USAGE in config.json:
#   module=/home/pipeline-server/user_scripts/gvapython/sscape/sscape_adapter_side.py
#
# FEATURES:
#   - Vehicle type detection (van, truck, bus, car)
#   - Color classification
#   - Axle counting with ground contact filtering
#   - ROI-aware (works with gvaattachroi)
# =============================================================================

import base64
import json
import logging
import os
import time
from collections import defaultdict
from datetime import datetime
from uuid import getnode as get_mac

import cv2
import ntplib
import paho.mqtt.client as mqtt
from pytz import timezone

from utils import publisher_utils as utils

# ==================== CONSTANTS ====================
ROOT_CA = os.environ.get('ROOT_CA', '/run/secrets/certs/scenescape-ca.pem')
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
TIMEZONE = "UTC"

DEBUG_MODE = os.environ.get('DEBUG_ADAPTER', 'false').lower() == 'true'

VEHICLE_TYPES = ('van', 'truck', 'bus', 'car', 'sedan', 'suv')
COLOR_LABELS = ('yellow', 'white', 'red', 'orange', 'grey', 'green', 'brown', 'blue', 'black')


# ==================== HELPER FUNCTIONS ====================

def getMACAddress():
    if 'MACADDR' in os.environ:
        return os.environ['MACADDR']
    a = get_mac()
    h = iter(hex(a)[2:].zfill(12))
    return ":".join(i + next(h) for i in h)


def computeObjBoundingBoxParams(pobj, fw, fh, x, y, w, h, xminnorm=None, yminnorm=None, xmaxnorm=None, ymaxnorm=None):
    try:
        xmax, xmin = int(xmaxnorm * fw), int(xminnorm * fw)
        ymax, ymin = int(ymaxnorm * fh), int(yminnorm * fh)
    except Exception:
        xmin, ymin, xmax, ymax = x, y, x + w, y + h

    comw, comh = (xmax - xmin) / 3, (ymax - ymin) / 4
    pobj.update({
        'center_of_mass': {'x': int(xmin + comw), 'y': int(ymin + comh), 'width': comw, 'height': comh},
        'bounding_box_px': {'x': x, 'y': y, 'width': w, 'height': h}
    })


def map_label_to_category(label):
    if not label:
        return 'unknown'
    lab = str(label).lower()
    if lab in ('vehicle', 'car', 'bus', 'truck', 'van', 'sedan', 'suv', 'motorcycle', 'bicycle'):
        return 'vehicle'
    if lab in ('person', 'pedestrian'):
        return 'pedestrian'
    if lab == 'axle':
        return 'axle'
    return 'unknown'


# ==================== GROUND/AXLE UTILITIES ====================

def get_ground_level(vehicle, axles, tolerance=150):
    """Calculate ground Y coordinate from vehicle and overlapping axles"""
    vehicle_bottom = vehicle.get('y', 0) + vehicle.get('height', 0)
    vehicle_x = vehicle.get('x', 0)
    vehicle_right = vehicle_x + vehicle.get('width', 0)

    overlapping_axle_bottoms = []
    for axle in axles:
        axle_x = axle.get('x', 0)
        axle_right = axle_x + axle.get('width', 0)
        if axle_right > vehicle_x - 50 and axle_x < vehicle_right + 50:
            axle_bottom = axle.get('y', 0) + axle.get('height', 0)
            overlapping_axle_bottoms.append(axle_bottom)

    all_bottoms = [vehicle_bottom] + overlapping_axle_bottoms
    return max(all_bottoms)


def classify_axles_ground_contact(axles, ground_y, tolerance=30):
    """Classify each axle as touching or not touching ground"""
    results = []
    for axle in axles:
        axle_bottom = axle.get('y', 0) + axle.get('height', 0)
        touching = axle_bottom >= (ground_y - tolerance)
        results.append({
            'x': axle.get('x', 0),
            'y': axle.get('y', 0),
            'width': axle.get('width', 0),
            'height': axle.get('height', 0),
            'touching_ground': touching,
            'confidence': axle.get('confidence', 0.0)
        })
    return results


def is_axle_inside_vehicle(axle, vehicle, margin=50):
    """Check if axle's center is inside vehicle bbox"""
    axle_cx = axle.get('x', 0) + axle.get('width', 0) / 2
    axle_cy = axle.get('y', 0) + axle.get('height', 0) / 2
    vx = vehicle.get('x', 0) - margin
    vy = vehicle.get('y', 0) - margin
    vw = vehicle.get('width', 0) + 2 * margin
    vh = vehicle.get('height', 0) + 2 * margin
    return (vx <= axle_cx <= vx + vw and vy <= axle_cy <= vy + vh)


# ==================== WHEEL DEDUPLICATION (IoU-based) ====================

def compute_iou(box1, box2):
    """
    Compute Intersection over Union (IoU) between two bounding boxes.
    Each box should have keys: x, y, width, height
    """
    x1_min = box1.get('x', 0)
    y1_min = box1.get('y', 0)
    x1_max = x1_min + box1.get('width', 0)
    y1_max = y1_min + box1.get('height', 0)

    x2_min = box2.get('x', 0)
    y2_min = box2.get('y', 0)
    x2_max = x2_min + box2.get('width', 0)
    y2_max = y2_min + box2.get('height', 0)

    # Intersection
    inter_x_min = max(x1_min, x2_min)
    inter_y_min = max(y1_min, y2_min)
    inter_x_max = min(x1_max, x2_max)
    inter_y_max = min(y1_max, y2_max)

    inter_width = max(0, inter_x_max - inter_x_min)
    inter_height = max(0, inter_y_max - inter_y_min)
    inter_area = inter_width * inter_height

    # Union
    area1 = box1.get('width', 0) * box1.get('height', 0)
    area2 = box2.get('width', 0) * box2.get('height', 0)
    union_area = area1 + area2 - inter_area

    if union_area == 0:
        return 0.0

    return inter_area / union_area


def deduplicate_wheels_by_iou(wheels, iou_threshold=0.4):
    """
    Remove overlapping wheel detections using Non-Maximum Suppression.
    Keeps highest confidence detection when overlap exceeds threshold.

    Args:
        wheels: List of wheel/axle detection dicts with x, y, width, height, confidence
        iou_threshold: Overlap threshold (0.4 = 40% overlap triggers dedup)

    Returns:
        List of unique wheel detections
    """
    if len(wheels) <= 1:
        return wheels

    # Sort by confidence (highest first)
    sorted_wheels = sorted(wheels, key=lambda w: w.get('confidence', 0), reverse=True)

    unique_wheels = []
    for wheel in sorted_wheels:
        is_duplicate = False
        for kept_wheel in unique_wheels:
            iou = compute_iou(wheel, kept_wheel)
            if iou > iou_threshold:
                is_duplicate = True
                if DEBUG_MODE:
                    print(f"   🔄 Removing duplicate wheel (IoU={iou:.2f}): {wheel}")
                break
        if not is_duplicate:
            unique_wheels.append(wheel)

    return unique_wheels


# ==================== TIMESTAMP CAPTURE ====================

class PostDecodeTimestampCapture:
    """Adds NTP-synchronized timestamps to each frame before inference"""

    def __init__(self, ntpServer=None):
        self.log = logging.getLogger('SSCAPE_ADAPTER_SIDE')
        self.log.setLevel(logging.INFO)
        self.ntpClient = ntplib.NTPClient()
        self.ntpServer = ntpServer
        self.lastTimeSync = None
        self.timeOffset = 0
        self.ts = None
        self.timestamp_for_next_block = None
        self.fps = 5.0
        self.fps_alpha = 0.75
        self.last_calculated_fps_ts = None
        self.fps_calc_interval = 1
        self.frame_cnt = 0

    def processFrame(self, frame):
        now = time.time()
        self.frame_cnt += 1
        if not self.last_calculated_fps_ts:
            self.last_calculated_fps_ts = now
        if (now - self.last_calculated_fps_ts) > self.fps_calc_interval:
            self.fps = self.fps * self.fps_alpha + (1 - self.fps_alpha) * (self.frame_cnt / (now - self.last_calculated_fps_ts))
            self.last_calculated_fps_ts = now
            self.frame_cnt = 0

        if self.ntpServer:
            if not self.lastTimeSync or now - self.lastTimeSync > 1000:
                response = self.ntpClient.request(host=self.ntpServer, port=123)
                self.timeOffset = response.offset
                self.lastTimeSync = now

        now += self.timeOffset
        self.timestamp_for_next_block = now
        frame.add_message(json.dumps({
            'postdecode_timestamp': f"{datetime.fromtimestamp(now, tz=timezone(TIMEZONE)).strftime(DATETIME_FORMAT)[:-3]}Z",
            'timestamp_for_next_block': now,
            'fps': self.fps
        }))
        return True


# ==================== VEHICLE ATTRIBUTE POLICY ====================

def vehicleAttributePolicy(pobj, item, fw, fh, all_detections):
    """
    Vehicle Attributes policy with ground-contact axle filtering.
    Handles vehicle type, color, and axle counting.
    """
    label = item.get('label', '')
    label_lower = str(label).lower() if label else ''
    vehicle_type_found = False

    # Check top-level label for vehicle type
    if label_lower in VEHICLE_TYPES:
        pobj['category'] = 'vehicle'
        pobj['vehicle_type'] = label_lower
        pobj['raw_label'] = label
        vehicle_type_found = True

    # Check tensors for vehicle type
    tensors_list = item.get('tensors') or item.get('tensor') or []
    if not vehicle_type_found and tensors_list:
        for tensor in tensors_list:
            tensor_label = str(tensor.get('label', '')).lower()
            if tensor_label in VEHICLE_TYPES:
                pobj['category'] = 'vehicle'
                pobj['vehicle_type'] = tensor_label
                pobj['raw_label'] = tensor.get('label', '')
                pobj['confidence'] = tensor.get('confidence') or 0.99
                vehicle_type_found = True
                break

    # Handle axle detections
    if label_lower == 'axle' or (not vehicle_type_found and
        any(str(t.get('label', '')).lower() == 'axle' for t in tensors_list)):
        pobj['category'] = 'axle'
        pobj['raw_label'] = 'axle'
        pobj['confidence'] = item.get('confidence') or 0.99
        if all(k in item for k in ('x', 'y', 'width', 'height')):
            pobj['bounding_box_px'] = {
                'x': item['x'], 'y': item['y'],
                'width': item['width'], 'height': item['height']
            }
        return

    if not vehicle_type_found:
        pobj['category'] = 'vehicle'

    raw_conf = item.get('confidence')
    pobj['confidence'] = raw_conf if raw_conf and raw_conf > 0 else 0.99

    # Bounding box
    if all(k in item for k in ('x', 'y', 'width', 'height')):
        pobj['bounding_box_px'] = {
            'x': item['x'], 'y': item['y'],
            'width': item['width'], 'height': item['height']
        }
        x, y, w, h = item['x'], item['y'], item['width'], item['height']
        pobj['center_of_mass'] = {
            'x': int(x + w / 3),
            'y': int(y + h / 4),
            'width': w / 3,
            'height': h / 4
        }

    # Extract color
    if 'tensor' in item or 'tensors' in item:
        for tensor in item.get('tensors') or item.get('tensor') or []:
            tensor_label = str(tensor.get('label', '')).lower()
            if tensor_label in COLOR_LABELS:
                pobj['vehicle_color'] = tensor_label
                break

    # Find axles associated with this vehicle (with deduplication)
    vehicle_obj_id = item.get('object_id')
    vehicle_axles = []
    seen_axle_ids = set()  # Track seen axle IDs to prevent double-adding

    for det in all_detections:
        det_label = str(det.get('label', '')).lower()
        if det_label == 'axle':
            # Create unique identifier for this detection
            det_id = det.get('object_id') or det.get('id') or id(det)

            # Skip if already added
            if det_id in seen_axle_ids:
                continue

            # Check if axle belongs to this vehicle
            belongs_to_vehicle = False
            if det.get('parent_id') == vehicle_obj_id and vehicle_obj_id is not None:
                belongs_to_vehicle = True
            elif is_axle_inside_vehicle(det, item):
                belongs_to_vehicle = True

            if belongs_to_vehicle:
                vehicle_axles.append(det)
                seen_axle_ids.add(det_id)

    # Remove overlapping wheel detections (same physical wheel detected twice)
    vehicle_axles = deduplicate_wheels_by_iou(vehicle_axles, iou_threshold=0.4)

    # Calculate ground level and classify axles
    if vehicle_axles:
        ground_y = get_ground_level(item, vehicle_axles)
        tolerance = 80  # Increased for lenience with shadows

        classified_axles = classify_axles_ground_contact(vehicle_axles, ground_y, tolerance)

        touching_count = sum(1 for a in classified_axles if a['touching_ground'])
        not_touching_count = len(classified_axles) - touching_count

        pobj['axle_count'] = len(classified_axles)
        pobj['wheel_count'] = len(classified_axles) * 2
        pobj['touching_ground'] = touching_count
        pobj['not_touching_ground'] = not_touching_count
        pobj['wheels_touching_ground'] = touching_count * 2
        pobj['wheels_not_touching_ground'] = not_touching_count * 2
        pobj['axles'] = classified_axles
        pobj['ground_y'] = ground_y
    else:
        pobj['axle_count'] = 0
        pobj['wheel_count'] = 0
        pobj['touching_ground'] = 0
        pobj['not_touching_ground'] = 0
        pobj['axles'] = []


metadatapolicies = {
    "vehicleAttributePolicy": vehicleAttributePolicy
}


# ==================== DATA PUBLISHER ====================

class PostInferenceDataPublish:
    """Publishes vehicle/axle inference data to MQTT"""

    def __init__(self, cameraid, metadatagenpolicy='vehicleAttributePolicy', publish_image=False):
        self.log = logging.getLogger('SSCAPE_ADAPTER_SIDE')
        self.log.setLevel(logging.INFO)
        self.cameraid = cameraid
        self.is_publish_image = publish_image
        self.is_publish_calibration_image = False
        self.setupMQTT()
        self.metadatagenpolicy = vehicleAttributePolicy
        self.frame_level_data = {'id': cameraid, 'debug_mac': getMACAddress()}

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print(f"Connected to MQTT Broker {self.broker}")
            self.client.subscribe(f"scenescape/cmd/camera/{self.cameraid}")
            print(f"Subscribed to topic: scenescape/cmd/camera/{self.cameraid}")
        else:
            print(f"Failed to connect, return code {rc}")

    def setupMQTT(self):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.broker = os.environ.get('MQTT_BROKER', 'broker.scenescape.intel.com')
        try:
            self.client.connect(self.broker, int(os.environ.get('MQTT_PORT', '1883')), 120)
        except Exception as e:
            self.log.error(f"Failed to connect to MQTT broker {self.broker}: {e}")
        self.client.on_message = self.handleCameraMessage
        if ROOT_CA and os.path.exists(ROOT_CA):
            self.client.tls_set(ca_certs=ROOT_CA)
        self.client.loop_start()

    def handleCameraMessage(self, client, userdata, message):
        msg = str(message.payload.decode("utf-8"))
        if msg == "getimage":
            self.is_publish_image = True
        elif msg == "getcalibrationimage":
            self.is_publish_calibration_image = True

    def annotateObjects(self, img):
        objColors = ((0, 0, 255), (255, 128, 128), (207, 83, 294), (31, 156, 238))
        for otype, objects in self.frame_level_data.get('objects', {}).items():
            if otype == "person":
                cindex = 0
            elif otype in ("vehicle", "bicycle", "license_plate", "sedan", "truck", "bus"):
                cindex = 1
            else:
                cindex = 2
            for obj in objects:
                try:
                    topleft_cv = (int(obj['bounding_box_px']['x']), int(obj['bounding_box_px']['y']))
                    bottomright_cv = (int(obj['bounding_box_px']['x'] + obj['bounding_box_px']['width']),
                                      int(obj['bounding_box_px']['y'] + obj['bounding_box_px']['height']))
                    cv2.rectangle(img, topleft_cv, bottomright_cv, objColors[cindex], 4)
                except Exception:
                    continue

    def annotateFPS(self, img, fpsval):
        fpsStr = f'FPS {fpsval:.1f}'
        scale = int((img.shape[0] + 479) / 480)
        cv2.putText(img, fpsStr, (0, 30 * scale), cv2.FONT_HERSHEY_SIMPLEX,
                    1 * scale, (0, 0, 0), 5 * scale)
        cv2.putText(img, fpsStr, (0, 30 * scale), cv2.FONT_HERSHEY_SIMPLEX,
                    1 * scale, (255, 255, 255), 2 * scale)

    def buildImgData(self, imgdatadict, gvaframe, annotate):
        """Build image data with error handling for corrupted buffers"""
        imgdatadict.update({
            'timestamp': self.frame_level_data.get('timestamp'),
            'id': self.cameraid
        })
        try:
            with gvaframe.data() as image:
                if annotate:
                    self.annotateObjects(image)
                    self.annotateFPS(image, self.frame_level_data.get('rate', 0.0))
                _, jpeg = cv2.imencode(".jpg", image)
            jpeg = base64.b64encode(jpeg).decode('utf-8')
            imgdatadict['image'] = jpeg
        except RuntimeError as e:
            self.log.error(f"Failed to build image data: {e}")
            imgdatadict['image'] = None

    def buildObjData(self, gvadata, frame):
        """Build object data with vehicle/axle-specific logic"""
        if DEBUG_MODE:
            print("🔧 SIDE ADAPTER: buildObjData")

        now = time.time()
        self.frame_level_data.update({
            'timestamp': gvadata.get('postdecode_timestamp'),
            'debug_timestamp_end': f"{datetime.fromtimestamp(now, tz=timezone(TIMEZONE)).strftime(DATETIME_FORMAT)[:-3]}Z",
            'debug_processing_time': now - float(gvadata.get('timestamp_for_next_block', now)),
            'rate': float(gvadata.get('fps', 0.0))
        })

        objects = defaultdict(list)
        resolution = gvadata.get('resolution', {})
        framewidth = resolution.get('width', 0)
        frameheight = resolution.get('height', 0)

        detections = gvadata.get('objects', None)
        if detections is None:
            detections = gvadata.get('gva_meta', [])

        # Flatten nested detections
        def get_all_detections_recursive(dets):
            all_dets = []
            if not dets:
                return all_dets
            for d in dets:
                all_dets.append(d)
                if 'objects' in d and isinstance(d['objects'], list):
                    all_dets.extend(get_all_detections_recursive(d['objects']))
            return all_dets

        all_flattened_detections = get_all_detections_recursive(detections)

        if DEBUG_MODE:
            print(f"DEBUG: Top-level detections: {len(detections)}")
            print(f"DEBUG: All flattened detections: {len(all_flattened_detections)}")
            labels = [d.get('label') for d in all_flattened_detections]
            print(f"DEBUG: All detection labels: {labels}")

        # Collect vehicles with their detections for image cropping later
        vehicles_to_process = []

        for det in all_flattened_detections:
            vaobj = {}

            vehicleAttributePolicy(vaobj, det, framewidth, frameheight, all_flattened_detections)
            vaobj['object_id'] = det.get('object_id')

            category = vaobj.get('category', 'unknown')
            det_label = det.get('label')

            if DEBUG_MODE:
                print(f"   📍 Detection: label='{det_label}' -> category='{category}'")

            # Skip axle detections - nested inside vehicles
            if category == 'axle':
                continue

            if category == 'vehicle':
                vaobj['id'] = len(objects['vehicle']) + 1
                objects['vehicle'].append(vaobj)
                # Store for image cropping
                vehicles_to_process.append(vaobj)
            elif category in ('person', 'pedestrian'):
                vaobj['id'] = len(objects['person']) + 1
                objects['person'].append(vaobj)

        # Capture vehicle side view images
        if vehicles_to_process:
            try:
                with frame.data() as image:
                    for vaobj in vehicles_to_process:
                        bbox = vaobj.get('bounding_box_px')
                        if bbox:
                            x = int(bbox.get('x', 0))
                            y = int(bbox.get('y', 0))
                            w = int(bbox.get('width', 0))
                            h = int(bbox.get('height', 0))

                            if w > 0 and h > 0:
                                vehicle_crop = image[y:y+h, x:x+w]
                                if vehicle_crop.size > 0:
                                    _, buffer = cv2.imencode('.jpg', vehicle_crop)
                                    vehicle_image_b64 = base64.b64encode(buffer).decode('utf-8')
                                    vaobj['vehicle_side_view_b64'] = vehicle_image_b64
                                    if DEBUG_MODE:
                                        print(f"✅ Vehicle side view captured: {len(vehicle_image_b64)} bytes for vehicle {vaobj.get('id')}")
            except Exception as e:
                self.log.error(f"Failed to crop vehicle side views: {e}")

        self.frame_level_data['objects'] = objects

    def processFrame(self, frame):
        """Main frame processing"""
        if self.client.is_connected():
            gvametadata, imgdatadict = {}, {}

            try:
                utils.get_gva_meta_messages(frame, gvametadata)
            except Exception:
                gvametadata = {}

            existing_objects = gvametadata.get('objects') or gvametadata.get('gva_meta')
            if not existing_objects:
                try:
                    gvametadata['objects'] = utils.get_gva_meta_regions(frame)
                except Exception:
                    gvametadata['objects'] = []
            elif gvametadata.get('gva_meta') and 'objects' not in gvametadata:
                gvametadata['objects'] = gvametadata['gva_meta']

            # Normalize detections
            for det in gvametadata.get('objects', []):
                if 'detection' in det:
                    d = det['detection']
                    if 'label' not in det:
                        det['label'] = d.get('label')
                    if 'confidence' not in det:
                        det['confidence'] = d.get('confidence')
                if 'w' in det and 'width' not in det:
                    det['width'] = det['w']
                if 'h' in det and 'height' not in det:
                    det['height'] = det['h']
                if det.get('object_id') is None and det.get('id') is not None:
                    det['object_id'] = det.get('id')

            if DEBUG_MODE:
                print("GVAMETADATA (raw detections):", gvametadata.get('objects', []))

            # Smart label defaulting
            for det in gvametadata.get('objects', []):
                if det.get('label') is None and det.get('object_id') is not None:
                    det['label'] = 'vehicle'

            self.buildObjData(gvametadata, frame)

            # Publish images (only if successfully captured)
            if self.is_publish_image:
                self.buildImgData(imgdatadict, frame, True)
                if imgdatadict.get('image') is not None:
                    self.client.publish(f"scenescape/image/camera/{self.cameraid}", json.dumps(imgdatadict))
                self.is_publish_image = False

            if self.is_publish_calibration_image:
                if not imgdatadict:
                    self.buildImgData(imgdatadict, frame, False)
                if imgdatadict.get('image') is not None:
                    self.client.publish(f"scenescape/image/calibration/camera/{self.cameraid}", json.dumps(imgdatadict))
                self.is_publish_calibration_image = False

            final_payload = json.dumps(self.frame_level_data)
            try:
                if DEBUG_MODE:
                    print("FINAL MQTT PAYLOAD:", json.dumps(self.frame_level_data, indent=2))
                self.client.publish(f"scenescape/data/camera/{self.cameraid}", final_payload)
            except Exception as e:
                self.log.error(f"Failed to publish to MQTT: {e}")

            try:
                frame.add_message(final_payload)
            except Exception:
                pass

        return True
