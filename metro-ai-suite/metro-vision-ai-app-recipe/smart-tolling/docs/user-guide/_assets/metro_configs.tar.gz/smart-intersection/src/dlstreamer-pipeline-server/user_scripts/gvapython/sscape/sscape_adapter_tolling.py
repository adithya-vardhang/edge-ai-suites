# =============================================================================
# Smart Tolling SceneScape Adapter
# =============================================================================
# Multi-policy adapter for tolling cameras with unified payload structure.
#
# ARCHITECTURE:
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ Camera          │ Policy                   │ Extra Fields              │
# ├─────────────────┼──────────────────────────┼───────────────────────────┤
# │ toll_front      │ lprPolicy / detection    │ license_plate, OCR text   │
# │ toll_rear       │ lprPolicy                │ license_plate, OCR text   │
# │ toll_side       │ vehicleAttributePolicy   │ vehicle_type, axle_count, vehicle_color │
# └─────────────────────────────────────────────────────────────────────────┘
#
# PAYLOAD STRUCTURE (unified for all cameras):
# {
#   "id": "camera_id",
#   "timestamp": "...",
#   "objects": {
#     "vehicle": [{id, category, center_of_mass, bounding_box_px, ...}],
#     "person": [...],
#     "license_plate": [...]
#   }
# }
# =============================================================================

import base64
import json
import logging
import os
import struct
import time
from collections import defaultdict
from datetime import datetime
from uuid import getnode as get_mac

import cv2
import ntplib
import paho.mqtt.client as mqtt
from pytz import timezone

from utils import publisher_utils as utils

ROOT_CA = os.environ.get('ROOT_CA', '/run/secrets/certs/scenescape-ca.pem')
DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
TIMEZONE = "UTC"

# ----------------- CONFIG -----------------
DEBUG_MODE = os.environ.get('DEBUG_ADAPTER', 'false').lower() == 'true'
ENABLE_OCR_MERGE = False       # Set True to merge fragmented OCR detections
OCR_MERGE_MAX_GAP_PX = 80      # max horizontal gap (pixels) between fragments to merge
OCR_MERGE_MAX_Y_OVERLAP = 0.5  # min fraction vertical overlap required to merge
MIN_PLATE_LENGTH = 6           # minimum valid plate text length
# ------------------------------------------

def getMACAddress():
    if 'MACADDR' in os.environ:
        return os.environ['MACADDR']

    a = get_mac()
    h = iter(hex(a)[2:].zfill(12))
    return ":".join(i + next(h) for i in h)


class PostDecodeTimestampCapture:
    """Adds NTP-synchronized timestamps to each frame before inference"""
    def __init__(self, ntpServer=None):
        self.log = logging.getLogger('SSCAPE_ADAPTER_TOLLING')
        self.log.setLevel(logging.INFO)
        self.ntpClient = ntplib.NTPClient()
        self.ntpServer = ntpServer
        self.lastTimeSync = None
        self.timeOffset = 0
        self.ts = None
        self.timestamp_for_next_block = None
        self.fps = 5.0
        self.fps_alpha = 0.75  # for weighted average
        self.last_calculated_fps_ts = None
        self.fps_calc_interval = 1  # calculate fps every 1s
        self.frame_cnt = 0

    def processFrame(self, frame):
        now = time.time()
        self.frame_cnt += 1
        if not self.last_calculated_fps_ts:
            self.last_calculated_fps_ts = now
        if (now - self.last_calculated_fps_ts) > self.fps_calc_interval:
            self.fps = self.fps * self.fps_alpha + (1 - self.fps_alpha) * (self.frame_cnt / (now - self.last_calculated_fps_ts))
            self.last_calculated_fps_ts = now
            self.frame_cnt = 0

        if self.ntpServer:
            # if ntpServer is available, check if it is time to recalibrate
            if not self.lastTimeSync or now - self.lastTimeSync > 1000:
                response = self.ntpClient.request(host=self.ntpServer, port=123)
                self.timeOffset = response.offset
                self.lastTimeSync = now

        now += self.timeOffset
        self.timestamp_for_next_block = now
        frame.add_message(json.dumps({
            'postdecode_timestamp': f"{datetime.fromtimestamp(now, tz=timezone(TIMEZONE)).strftime(DATETIME_FORMAT)[:-3]}Z",
            'timestamp_for_next_block': now,
            'fps': self.fps
        }))
        return True


def computeObjBoundingBoxParams(pobj, fw, fh, x, y, w, h, xminnorm=None, yminnorm=None, xmaxnorm=None, ymaxnorm=None):
    """Calculate center of mass and bounding box"""
    try:
        xmax, xmin = int(xmaxnorm * fw), int(xminnorm * fw)
        ymax, ymin = int(ymaxnorm * fh), int(yminnorm * fh)
    except Exception:
        # fallback if normalized values are missing/invalid
        xmin, ymin, xmax, ymax = x, y, x + w, y + h

    comw, comh = (xmax - xmin) / 3, (ymax - ymin) / 4

    pobj.update({
        'center_of_mass': {'x': int(xmin + comw), 'y': int(ymin + comh), 'width': comw, 'height': comh},
        'bounding_box_px': {'x': x, 'y': y, 'width': w, 'height': h}
    })

    return


# Helper to map free-form labels to stable categories for dashboard
def map_label_to_category(label):
    if not label:
        return 'unknown'
    lab = str(label).lower()

    if any(ch.isdigit() for ch in lab) and any(ch.isalpha() for ch in lab):
        # text contains both letters and digits (e.g. TS09AB1234)
        return 'license_plate'
    if 'plate' in lab or 'english' in lab:
        return 'license_plate'
    if lab in ('vehicle', 'car', 'bus', 'truck', 'van', 'sedan', 'suv', 'motorcycle', 'bicycle'):
        return 'vehicle'
    if lab in ('person', 'pedestrian'):
        return 'pedestrian'
    return 'unknown'


def is_plate_text_valid(plate_text):
    """
    Checks if a license plate string is valid enough to warrant an image crop.
    """
    if not plate_text:
        return False
    
    plate_text = plate_text.strip()

    # Rule 1: Check minimum length
    if len(plate_text) < MIN_PLATE_LENGTH:
        return False
        
    # Rule 2: Check for a mix of letters and numbers (a common heuristic)
    has_letter = any(c.isalpha() for c in plate_text)
    has_digit = any(c.isdigit() for c in plate_text)
    
    if not (has_letter and has_digit):
        # This filters out junk like "AAAAAAA" or "1111111"
        return False

    # All checks passed
    return True


# ----------------- OCR merge helper -----------------
def _bbox_right_x(det):
    """helper: right x of detection"""
    return det.get('x', 0) + det.get('width', det.get('w', 0))

def _bbox_left_x(det):
    return det.get('x', 0)

def _bbox_top_y(det):
    return det.get('y', 0)

def _bbox_bottom_y(det):
    return det.get('y', 0) + det.get('height', det.get('h', 0))

def _vertical_overlap_fraction(a, b):
    a_top, a_bottom = _bbox_top_y(a), _bbox_bottom_y(a)
    b_top, b_bottom = _bbox_top_y(b), _bbox_bottom_y(b)
    inter_top = max(a_top, b_top)
    inter_bottom = min(a_bottom, b_bottom)
    inter_h = max(0, inter_bottom - inter_top)
    a_h = max(1, a_bottom - a_top)
    return inter_h / a_h

def merge_ocr_detections(dets, max_gap_px=OCR_MERGE_MAX_GAP_PX, min_vertical_overlap=OCR_MERGE_MAX_Y_OVERLAP):
    """
    Merge horizontally close OCR fragment detections into a single detection.
    """
    if not dets:
        return []

    dets_sorted = sorted([dict(d) for d in dets], key=lambda d: d.get('x', 0))
    merged = []
    curr = dets_sorted[0].copy()
    curr_text = ''
    if 'tensor' in curr and curr['tensor']:
        curr_text = ''.join([str(t.get('label', '')) for t in curr['tensor'] if t.get('label')])
    else:
        curr_text = curr.get('text', '') or ''

    for d in dets_sorted[1:]:
        d_text = ''
        if 'tensor' in d and d['tensor']:
            d_text = ''.join([str(t.get('label', '')) for t in d['tensor'] if t.get('label')])
        else:
            d_text = d.get('text', '') or ''

        gap = d.get('x', 0) - _bbox_right_x(curr)
        v_overlap = _vertical_overlap_fraction(curr, d)

        if gap <= max_gap_px and v_overlap >= min_vertical_overlap:
            curr_text = (curr_text or '') + (d_text or '')
            left = min(_bbox_left_x(curr), _bbox_left_x(d))
            right = max(_bbox_right_x(curr), _bbox_right_x(d))
            top = min(_bbox_top_y(curr), _bbox_top_y(d))
            bottom = max(_bbox_bottom_y(curr), _bbox_bottom_y(d))
            curr['x'] = int(left)
            curr['y'] = int(top)
            curr['width'] = int(right - left)
            curr['height'] = int(bottom - top)
            curr['object_id'] = curr.get('object_id') or None
        else:
            if curr_text:
                curr['tensor'] = [{'name': 'classification', 'label': curr_text, 'confidence': 0.0}]
                curr['merged_text'] = curr_text
            merged.append(curr)
            curr = d.copy()
            curr_text = d_text

    if curr_text:
        curr['tensor'] = [{'name': 'classification', 'label': curr_text, 'confidence': 0.0}]
        curr['merged_text'] = curr_text
    merged.append(curr)
    return merged
# ---------------------------------------------------------


def detectionPolicy(pobj, item, fw, fh):
    """
    Hybrid version - works with both nested and flat detection structures
    Also handles LPR detection where OCR text is in tensor[0]['label']
    """
    # Try nested structure first (edge adapter format)
    if 'detection' in item:
        pobj.update({
            'category': item['detection'].get('label', 'unknown'),
            'confidence': item['detection'].get('confidence', 0.0)
        })
        
        # Robust extraction of coordinates
        x = item.get('x')
        y = item.get('y')
        w = item.get('width') or item.get('w')
        h = item.get('height') or item.get('h')
        
        computeObjBoundingBoxParams(pobj, fw, fh, x, y, w, h,
                                    item['detection']['bounding_box']['x_min'],
                                    item['detection']['bounding_box']['y_min'],
                                    item['detection']['bounding_box']['x_max'],
                                    item['detection']['bounding_box']['y_max'])
    else:
        # Flat structure (regular adapter format)
        label = item.get('label') or item.get('text')
        
        # Check tensors for additional info
        ocr_text = None
        detection_label = None
        detection_confidence = None
        
        if 'tensor' in item or 'tensors' in item:
            for t in item.get('tensors') or item.get('tensor') or []:
                tensor_name = t.get('name', '')
                tensor_label = t.get('label')
                tensor_confidence = t.get('confidence')
                
                if tensor_label:
                    # DETECTION tensor: label is the object category (vehicle, person)
                    if tensor_name == 'detection':
                        detection_label = tensor_label
                        detection_confidence = tensor_confidence
                    # CLASSIFICATION tensor: label is OCR text (license plate)
                    elif tensor_name == 'classification':
                        # Check if this looks like plate text (has both letters and digits)
                        if any(c.isdigit() for c in str(tensor_label)) and any(c.isalpha() for c in str(tensor_label)):
                            ocr_text = tensor_label
                            break
                        # Also accept longer strings that might be partial plates
                        if len(str(tensor_label)) >= 4:
                            ocr_text = tensor_label
                            break
        
        # Determine category based on what we found
        if detection_label:
            # Use detection tensor label as category
            pobj['category'] = map_label_to_category(detection_label)
            pobj['confidence'] = detection_confidence if detection_confidence else 0.99
        elif ocr_text:
            # This is a license plate detection from OCR classification
            pobj['category'] = 'license_plate'
            pobj['license_plate_text'] = ocr_text
            pobj['confidence'] = item.get('confidence', 0.99)
        elif label:
            pobj['category'] = map_label_to_category(label)
            pobj['confidence'] = item.get('confidence', 0.99)
        else:
            # No label and no OCR - unknown
            pobj['category'] = 'unknown'
            pobj['confidence'] = item.get('confidence', 0.99)
        
        # Compute bounding box
        # Handle both width/height and w/h keys
        x = item.get('x')
        y = item.get('y')
        w = item.get('width') or item.get('w')
        h = item.get('height') or item.get('h')

        if x is not None and y is not None and w is not None and h is not None:
            computeObjBoundingBoxParams(
                pobj, fw, fh,
                x, y, w, h,
                xminnorm=x / fw if fw > 0 else 0,
                yminnorm=y / fh if fh > 0 else 0,
                xmaxnorm=(x + w) / fw if fw > 0 else 1,
                ymaxnorm=(y + h) / fh if fh > 0 else 1
            )
    
    return


def reidPolicy(pobj, item, fw, fh):
    detectionPolicy(pobj, item, fw, fh)
    try:
        reid_vector = item['tensors'][1]['data']
        v = struct.pack("256f", *reid_vector)
        pobj['reid'] = base64.b64encode(v).decode('utf-8')
    except Exception:
        pass
    return


def classificationPolicy(pobj, item, fw, fh):
    detectionPolicy(pobj, item, fw, fh)
    try:
        pobj['category'] = item['classification_layer_name:efficientnet-b0/model/head/dense/BiasAdd:0']['label']
    except Exception:
        pass
    return


def lprPolicy(pobj, item, fw, fh):
    """License Plate Recognition policy for Camera 1 & 2 (front/rear)"""
    # Base extraction (bounding box, confidence, etc.)
    detectionPolicy(pobj, item, fw, fh)

    label = item.get('label')

    # if label == 'vehicle' and pobj.get('category') != 'license_plate':
    #     pobj['category'] = 'vehicle'
    if str(label) in ('vehicle', '0') and pobj.get('category') != 'license_plate':
        pobj['category'] = 'vehicle'

    elif label == 'English' or pobj.get('category') == 'license_plate':
        pobj['category'] = 'license_plate'
        # Try to get OCR text
        ocr_text = item.get('text')

        # If text not found, fallback to tensor labels (some models put OCR text there)
        tensors_list = item.get('tensors') or item.get('tensor') or []
        if not ocr_text and tensors_list:
            for t in tensors_list:
                if t.get('label'):
                    ocr_text = t['label']
                    break

        # Check for classification layer keys (seen in some configs)
        if not ocr_text:
            for k, v in item.items():
                if k.startswith('classification_layer_name:') and isinstance(v, dict):
                    if v.get('label'):
                        ocr_text = v['label']
                        break

        # If OCR text found, save it
        if ocr_text:
            pobj['license_plate_text'] = ocr_text

    return


def vehicleAttributePolicy(pobj, item, fw, fh, ground_calibration=None, frame_height=None):
    """
    Vehicle Attributes policy for Camera 3 (side view)
    Extracts: vehicle class, axle count (ground-touching wheels), color
    Uses models: vehicle_type_model, axle_int8, color_model_int8
    """
    # 1. Base detection info
    label = item.get('label')
    
    # Vehicle type from model (van, truck, bus, car) - stored in vehicle_type
    # But CATEGORY must always be 'vehicle' for SceneScape
    pobj['category'] = 'vehicle'  # Required for SceneScape
    if label:
        pobj['vehicle_type'] = label  # Specific type
    else:
        # Do not set vehicle_type to 'unknown'
        pass
    
    # Confidence - MUST be > 0.0 for SceneScape validation
    raw_confidence = item.get('confidence')
    if raw_confidence is not None and raw_confidence > 0:
        pobj['confidence'] = raw_confidence
    else:
        pobj['confidence'] = 0.99  # Default valid confidence
    
    # Bounding box AND center_of_mass (required for SceneScape)
    x = item.get('x')
    y = item.get('y')
    w = item.get('width') or item.get('w')
    h = item.get('height') or item.get('h')
    
    if x is not None and y is not None and w is not None and h is not None:
        pobj['bounding_box_px'] = {'x': x, 'y': y, 'width': w, 'height': h}
        # Calculate center_of_mass (same formula as computeObjBoundingBoxParams)
        comw, comh = w / 3, h / 4
        pobj['center_of_mass'] = {
            'x': int(x + comw),
            'y': int(y + comh),
            'width': comw,
            'height': comh
        }
    
    # 2. Extract color from color_model_int8 classification
    # 2. Extract color from color_model_int8 classification
    # pobj['vehicle_color'] = 'unknown'  # Default - REMOVED to avoid validation errors
    
    # Check direct color field first
    if 'color' in item:
        pobj['vehicle_color'] = item['color']
    elif 'classification' in item:
        if 'color' in item['classification']:
            pobj['vehicle_color'] = item['classification']['color']
    
    # Check tensor data for color classification result
    if 'tensor' in item:
        for tensor in item['tensor']:
            # Color model outputs label directly
            tensor_label = tensor.get('label', '')
            if tensor_label and tensor_label.lower() in ('yellow', 'white', 'red', 'orange', 'grey', 'green', 'brown', 'blue', 'black'):
                pobj['vehicle_color'] = tensor_label.lower()
                break
            # Also check name field
            if tensor.get('name') == 'color_classification':
                pobj['vehicle_color'] = tensor.get('label', 'unknown')
    
    return


def get_ground_level(vehicle, axles, tolerance=150):
    """
    Calculate ground Y coordinate from vehicle and overlapping axles.
    Ground = max(vehicle_bottom, max(overlapping_axle_bottoms))
    """
    # Start with vehicle bottom
    vehicle_bottom = vehicle.get('y', 0) + vehicle.get('height', 0)
    
    # Consider axle bottoms that overlap horizontally with vehicle
    vehicle_x = vehicle.get('x', 0)
    vehicle_right = vehicle_x + vehicle.get('width', 0)
    
    overlapping_axle_bottoms = []
    for axle in axles:
        axle_x = axle.get('x', 0)
        axle_right = axle_x + axle.get('width', 0)
        
        # Check horizontal overlap (with some margin)
        if axle_right > vehicle_x - 50 and axle_x < vehicle_right + 50:
            axle_bottom = axle.get('y', 0) + axle.get('height', 0)
            overlapping_axle_bottoms.append(axle_bottom)
    
    # Ground is the maximum of vehicle bottom and axle bottoms
    all_bottoms = [vehicle_bottom] + overlapping_axle_bottoms
    return max(all_bottoms)


def classify_axles_ground_contact(axles, ground_y, tolerance=30):
    """
    Classify each axle as touching or not touching ground.
    Returns list of axle dicts with 'touching_ground' field added.
    """
    results = []
    for axle in axles:
        axle_bottom = axle.get('y', 0) + axle.get('height', 0)
        
        # Axle is touching ground if its bottom is within tolerance of ground_y
        touching = axle_bottom >= (ground_y - tolerance)
        
        results.append({
            'x': axle.get('x', 0),
            'y': axle.get('y', 0),
            'width': axle.get('width', 0),
            'height': axle.get('height', 0),
            'touching_ground': touching,
            'confidence': axle.get('confidence', 0.0)
        })
    return results


def is_axle_inside_vehicle(axle, vehicle, margin=50):
    """
    Check if axle's center is inside vehicle bbox (with margin).
    Used as fallback when parent_id is not available.
    """
    axle_cx = axle.get('x', 0) + axle.get('width', 0) / 2
    axle_cy = axle.get('y', 0) + axle.get('height', 0) / 2
    
    vx = vehicle.get('x', 0) - margin
    vy = vehicle.get('y', 0) - margin
    vw = vehicle.get('width', 0) + 2 * margin
    vh = vehicle.get('height', 0) + 2 * margin
    
    return (vx <= axle_cx <= vx + vw and vy <= axle_cy <= vy + vh)


def vehicleAttributePolicyWithGroundFilter(pobj, item, fw, fh, all_detections):
    """
    Enhanced vehicle attributes policy for Camera 3 (side view).
    Handles:
    - Vehicle type extraction (van, truck, bus, car)
    - Color classification
    - Axle counting with ground contact detection
    - Wheel count = axle_count × 2
    """
    # Vehicle types from vehicle_type_model
    VEHICLE_TYPES = ('van', 'truck', 'bus', 'car', 'sedan', 'suv')
    
    # 1. Extract vehicle type - check both top-level label and tensor labels
    label = item.get('label', '')
    label_lower = str(label).lower() if label else ''
    vehicle_type_found = False
    
    # First check top-level label
    if label_lower in VEHICLE_TYPES:
        pobj['category'] = 'vehicle'
        pobj['vehicle_type'] = label_lower
        pobj['raw_label'] = label
        vehicle_type_found = True
    
    # If not found at top level, check inside tensor (detection outputs)
    tensors_list = item.get('tensors') or item.get('tensor') or []
    if not vehicle_type_found and tensors_list:
        for tensor in tensors_list:
            tensor_name = str(tensor.get('name', '')).lower()
            tensor_label = str(tensor.get('label', '')).lower()
            # Look for 'detection' tensor or any tensor with vehicle type label
            if tensor_label in VEHICLE_TYPES:
                pobj['category'] = 'vehicle'
                pobj['vehicle_type'] = tensor_label
                pobj['raw_label'] = tensor.get('label', '')
                pobj['confidence'] = tensor.get('confidence') or 0.99
                vehicle_type_found = True
                break
    
    # Handle axle detections
    if label_lower == 'axle' or (not vehicle_type_found and 'tensor' in item and 
        any(str(t.get('label', '')).lower() == 'axle' for t in item.get('tensor', []))):
        pobj['category'] = 'axle'
        pobj['raw_label'] = 'axle'
        pobj['confidence'] = item.get('confidence') or 0.99
        if all(k in item for k in ('x', 'y', 'width', 'height')):
            pobj['bounding_box_px'] = {
                'x': item['x'], 'y': item['y'],
                'width': item['width'], 'height': item['height']
            }
        return  # Axles are handled separately, not added to payload directly
    
    # Default to unknown if no vehicle type found
    if not vehicle_type_found:
        pobj['category'] = 'vehicle'
        # Do not set vehicle_type to 'unknown' to avoid validation errors
        # pobj['vehicle_type'] = 'unknown'
    
    # Confidence - MUST be > 0.0 for SceneScape
    raw_conf = item.get('confidence')
    pobj['confidence'] = raw_conf if raw_conf and raw_conf > 0 else 0.99
    
    # 2. Bounding box
    if all(k in item for k in ('x', 'y', 'width', 'height')):
        pobj['bounding_box_px'] = {
            'x': item['x'], 'y': item['y'],
            'width': item['width'], 'height': item['height']
        }
        # Also calculate center_of_mass
        x, y, w, h = item['x'], item['y'], item['width'], item['height']
        pobj['center_of_mass'] = {
            'x': int(x + w / 3),
            'y': int(y + h / 4),
            'width': w / 3,
            'height': h / 4
        }
    
    # 3. Extract color from color_model_int8 classification
    color_found = False
    COLOR_LABELS = ('yellow', 'white', 'red', 'orange', 'grey', 'green', 'brown', 'blue', 'black')
    
    if 'tensor' in item or 'tensors' in item:
        for tensor in item.get('tensors') or item.get('tensor') or []:
            tensor_label = str(tensor.get('label', '')).lower()
            if tensor_label in COLOR_LABELS:
                pobj['vehicle_color'] = tensor_label
                color_found = True
                break
    
    if not color_found:
        pass # Do not set vehicle_color to 'unknown'
        # pobj['vehicle_color'] = 'unknown'
    
    # 4. Find all axle detections associated with this vehicle
    vehicle_obj_id = item.get('object_id')
    vehicle_axles = []
    
    for det in all_detections:
        det_label = str(det.get('label', '')).lower()
        if det_label == 'axle':
            # Try parent_id first
            if det.get('parent_id') == vehicle_obj_id and vehicle_obj_id is not None:
                vehicle_axles.append(det)
            # Fallback: spatial matching
            elif is_axle_inside_vehicle(det, item):
                vehicle_axles.append(det)
    
    # 5. Calculate ground level and classify axles (same logic as wheel_ground_detection.py)
    if vehicle_axles:
        # Ground = max(vehicle_bottom, max(overlapping_axle_bottoms))
        ground_y = get_ground_level(item, vehicle_axles)
        tolerance = 80  # INCREASED from 30 to 80 for more lenience with shadows
        
        # Classify each axle
        classified_axles = classify_axles_ground_contact(vehicle_axles, ground_y, tolerance)
        
        # Count touching vs not touching
        touching_count = sum(1 for a in classified_axles if a['touching_ground'])
        not_touching_count = len(classified_axles) - touching_count
        
        # Populate vehicle object
        pobj['axle_count'] = len(classified_axles)
        pobj['wheel_count'] = len(classified_axles) * 2  # Each axle has 2 wheels
        pobj['touching_ground'] = touching_count
        pobj['not_touching_ground'] = not_touching_count
        # User requested specific wheel counts for ground contact
        pobj['wheels_touching_ground'] = touching_count * 2
        pobj['wheels_not_touching_ground'] = not_touching_count * 2
        pobj['axles'] = classified_axles
        pobj['ground_y'] = ground_y  # Debug info
    else:
        # No axles detected
        pobj['axle_count'] = 0
        pobj['wheel_count'] = 0
        pobj['touching_ground'] = 0
        pobj['not_touching_ground'] = 0
        pobj['axles'] = []
    
    return


metadatapolicies = {
    "detectionPolicy": detectionPolicy,
    "reidPolicy": reidPolicy,
    "classificationPolicy": classificationPolicy,
    "lprPolicy": lprPolicy,
    "vehicleAttributePolicy": vehicleAttributePolicy  # NEW for Camera 3
}


class PostInferenceDataPublish:
    """Publishes inference data to MQTT in SceneScape format"""
    
    def __init__(self, cameraid, metadatagenpolicy='detectionPolicy', publish_image=False):
        self.log = logging.getLogger('SSCAPE_ADAPTER_TOLLING')
        self.log.setLevel(logging.INFO)
        self.cameraid = cameraid
        self.is_publish_image = publish_image
        self.is_publish_calibration_image = False
        self.setupMQTT()
        # safe fallback if policy name not recognized
        self.metadatagenpolicy = metadatapolicies.get(metadatagenpolicy, detectionPolicy)
        self.frame_level_data = {'id': cameraid, 'debug_mac': getMACAddress()}
        
        return

    

    def on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print(f"Connected to MQTT Broker {self.broker}")
            self.client.subscribe(f"scenescape/cmd/camera/{self.cameraid}")
            print(f"Subscribed to topic: scenescape/cmd/camera/{self.cameraid}")
        else:
            print(f"Failed to connect, return code {rc}")
        return

    def setupMQTT(self):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.broker = os.environ.get('MQTT_BROKER', 'broker.scenescape.intel.com')
        try:
            self.client.connect(self.broker, int(os.environ.get('MQTT_PORT', '1883')), 120)
        except Exception as e:
            self.log.error(f"Failed to connect to MQTT broker {self.broker}: {e}")
        self.client.on_message = self.handleCameraMessage
        if ROOT_CA and os.path.exists(ROOT_CA):
            self.client.tls_set(ca_certs=ROOT_CA)
        self.client.loop_start()
        return

    def handleCameraMessage(self, client, userdata, message):
        msg = str(message.payload.decode("utf-8"))
        if msg == "getimage":
            self.is_publish_image = True
        elif msg == "getcalibrationimage":
            self.is_publish_calibration_image = True
        return

    def annotateObjects(self, img):
        objColors = ((0, 0, 255), (255, 128, 128), (207, 83, 294), (31, 156, 238))
        # frame_level_data['objects'] is a dict of lists
        for otype, objects in self.frame_level_data.get('objects', {}).items():
            if otype == "person":
                cindex = 0
            elif otype in ("vehicle", "bicycle", "license_plate", "sedan", "truck", "bus"):
                cindex = 1
            else:
                cindex = 2
            for obj in objects:
                try:
                    topleft_cv = (int(obj['bounding_box_px']['x']), int(obj['bounding_box_px']['y']))
                    bottomright_cv = (int(obj['bounding_box_px']['x'] + obj['bounding_box_px']['width']),
                                      int(obj['bounding_box_px']['y'] + obj['bounding_box_px']['height']))
                    cv2.rectangle(img, topleft_cv, bottomright_cv, objColors[cindex], 4)
                except Exception:
                    # skip malformed objs
                    continue
        return

    def annotateFPS(self, img, fpsval):
        fpsStr = f'FPS {fpsval:.1f}'
        scale = int((img.shape[0] + 479) / 480)
        cv2.putText(img, fpsStr, (0, 30 * scale), cv2.FONT_HERSHEY_SIMPLEX,
                    1 * scale, (0, 0, 0), 5 * scale)
        cv2.putText(img, fpsStr, (0, 30 * scale), cv2.FONT_HERSHEY_SIMPLEX,
                    1 * scale, (255, 255, 255), 2 * scale)
        return

    def buildImgData(self, imgdatadict, gvaframe, annotate):
        imgdatadict.update({
            'timestamp': self.frame_level_data.get('timestamp'),
            'id': self.cameraid
        })
        with gvaframe.data() as image:
            if annotate:
                self.annotateObjects(image)
                self.annotateFPS(image, self.frame_level_data.get('rate', 0.0))
            _, jpeg = cv2.imencode(".jpg", image)
        jpeg = base64.b64encode(jpeg).decode('utf-8')
        imgdatadict['image'] = jpeg
        return

    def buildObjData(self, gvadata, frame):
        if DEBUG_MODE:
            print("🔧 TOLLING ADAPTER: buildObjData")
        now = time.time()
        self.frame_level_data.update({
            'timestamp': gvadata.get('postdecode_timestamp'),
            'debug_timestamp_end': f"{datetime.fromtimestamp(now, tz=timezone(TIMEZONE)).strftime(DATETIME_FORMAT)[:-3]}Z",
            'debug_processing_time': now - float(gvadata.get('timestamp_for_next_block', now)),
            'rate': float(gvadata.get('fps', 0.0))
        })

        objects = defaultdict(list)
        resolution = gvadata.get('resolution', {})
        framewidth = resolution.get('width', 0)
        frameheight = resolution.get('height', 0)

        # Dictionary to hold license plates and their associated OCR characters
        lp_data = {}

        # Support both 'objects' (preferred) and legacy 'gva_meta'
        detections = gvadata.get('objects', None)
        if detections is None:
            detections = gvadata.get('gva_meta', [])

        # ---------- MERGE OCR FRAGMENTS (if enabled) ----------
        if ENABLE_OCR_MERGE and detections:
            # identify candidate OCR fragment detections:
            ocr_candidates = []
            other_dets = []
            for det in detections:
                has_tensor_label = False
                if 'tensor' in det and det['tensor']:
                    for t in det['tensor']:
                        if t.get('label'):
                            has_tensor_label = True
                            break
                # treat fragments with no object_id or small width as candidates
                if has_tensor_label and (det.get('object_id') is None or det.get('width', det.get('w', 0)) < (framewidth * 0.5)):
                    ocr_candidates.append(det)
                else:
                    other_dets.append(det)

            # perform merge on candidates
            if ocr_candidates:
                merged = merge_ocr_detections(ocr_candidates)
                # final detections = other_dets + merged
                detections = other_dets + merged
        # -------------------------------------------------------

        # First pass: Group all objects by their object ID
        all_objects_by_id = {det.get('object_id'): det for det in detections if det.get('object_id') is not None}

        # Second pass: collect characters belonging to a license plate
        for det in detections:
            parent_id = det.get('parent_id')
            # some OCR setups use label 'character' for plate characters
            if det.get('label') == 'character' and parent_id is not None:
                parent_lp = all_objects_by_id.get(parent_id)
                if parent_lp:
                    if parent_id not in lp_data:
                        lp_data[parent_id] = {'text': '', 'confidence': []}
                    lp_data[parent_id]['text'] += det.get('text', '')
                    if det.get('confidence') is not None:
                        lp_data[parent_id]['confidence'].append(det.get('confidence'))

        # Third pass: Build the final object list for publishing
        # TWO-PASS APPROACH: First collect vehicles, then attach plates (matching working adapter)
        
        vehicle_objects_by_det_id = {}  # Maps detection object_id -> vehicle vaobj
        plate_detections = []  # Store plate detections for second pass
        
        # Helper to flatten nested detections (axles might be inside vehicles)
        def get_all_detections_recursive(dets):
            all_dets = []
            if not dets:
                return all_dets
            for d in dets:
                all_dets.append(d)
                # Check for nested objects (common in gvametaconvert JSON)
                if 'objects' in d and isinstance(d['objects'], list):
                    all_dets.extend(get_all_detections_recursive(d['objects']))
            return all_dets

        # Flatten detections for looking up relations (plates, axles)
        all_flattened_detections = get_all_detections_recursive(detections)

        if DEBUG_MODE:
             print(f"DEBUG: Top-level detections: {len(detections)}")
             print(f"DEBUG: All flattened detections: {len(all_flattened_detections)}")
             # Print labels of all flattened detections to verify axles are present
             labels = [d.get('label') for d in all_flattened_detections]
             print(f"DEBUG: All detection labels: {labels}")

        for det in all_flattened_detections:
            vaobj = {}
            # If this is the license plate region (e.g., detector label 'English') and we have aggregated characters:
            if det.get('label') in ('English', 'license_plate') and det.get('object_id') in lp_data:
                ocr_text = lp_data[det['object_id']]['text']
                confidences = lp_data[det['object_id']]['confidence']
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0
                det['text'] = ocr_text
                det['confidence'] = avg_confidence

            # Apply metadata policy
            # If policy is vehicleAttributePolicy, use the enhanced version with ground-touching wheel filtering
            # This is decoupled from camera ID - any camera can use this policy
            if self.metadatagenpolicy == vehicleAttributePolicy:
                # Use enhanced policy that filters ground-touching wheels
                vehicleAttributePolicyWithGroundFilter(
                    vaobj, det, framewidth, frameheight, 
                    all_flattened_detections  # Pass flattened detections for axle matching
                )
            else:
                # Standard policy for other cameras (front/rear LPR)
                self.metadatagenpolicy(vaobj, det, framewidth, frameheight)

            # Add the tracker's object_id (essential for backend)
            vaobj['object_id'] = det.get('object_id')
            
            category = vaobj.get('category', 'unknown')
            det_label = det.get('label')
            
            if DEBUG_MODE:
                print(f"   📍 Detection: label='{det_label}' -> category='{category}'")
            
            # Skip axle detections - they are nested inside vehicles, not top-level objects
            if category == 'axle':
                continue
            
            # If it's a vehicle, add it and track for plate linking
            if category == 'vehicle':
                vaobj['id'] = len(objects['vehicle']) + 1
                objects['vehicle'].append(vaobj)
                # Track by object_id for plate linking
                det_obj_id = det.get('object_id')
                if det_obj_id is not None:
                    vehicle_objects_by_det_id[det_obj_id] = vaobj
                    
            # If it's a license plate, save for second pass
            elif category == 'license_plate':
                # Only include plates with valid text
                if 'license_plate_text' in vaobj:
                    plate_detections.append((det, vaobj))
                    
            # Person/pedestrian - add directly
            elif category in ('person', 'pedestrian'):
                vaobj['id'] = len(objects['person']) + 1
                objects['person'].append(vaobj)
            # Skip 'unknown' category to keep payload clean
        
        # Pass 3b: Attach plates to parent vehicles (copied from working adapter)
        def is_bbox_inside(inner_bbox, outer_bbox):
            """Check if inner_bbox center is inside outer_bbox"""
            inner_cx = inner_bbox['x'] + inner_bbox['width'] / 2
            inner_cy = inner_bbox['y'] + inner_bbox['height'] / 2
            return (outer_bbox['x'] <= inner_cx <= outer_bbox['x'] + outer_bbox['width'] and
                    outer_bbox['y'] <= inner_cy <= outer_bbox['y'] + outer_bbox['height'])
        
        for det, vaobj in plate_detections:
            plate_text = vaobj.get('license_plate_text')
            plate_bbox = vaobj.get('bounding_box_px')
            parent_id = det.get('parent_id')
            
            # SPATIAL MATCHING: If no parent_id, find vehicle that contains this plate
            matched_vehicle = None
            if parent_id and parent_id in vehicle_objects_by_det_id:
                matched_vehicle = vehicle_objects_by_det_id[parent_id]
            else:
                # Fallback: Find vehicle whose bbox contains the plate
                for vehicle in objects.get('vehicle', []):
                    vehicle_bbox = vehicle.get('bounding_box_px')
                    if vehicle_bbox and plate_bbox and is_bbox_inside(plate_bbox, vehicle_bbox):
                        matched_vehicle = vehicle
                        break
            
            # Crop the plate image if valid
            plate_image_b64 = None
            if is_plate_text_valid(plate_text):
                if matched_vehicle:
                    try:
                        parent_bbox = matched_vehicle['bounding_box_px']
                        parent_x = int(parent_bbox['x'])
                        parent_y = int(parent_bbox['y'])
                        parent_w = int(parent_bbox['width'])
                        parent_h = int(parent_bbox['height'])
                        plate_abs_x = int(plate_bbox['x'])
                        plate_abs_y = int(plate_bbox['y'])
                        plate_w = int(plate_bbox['width'])
                        plate_h = int(plate_bbox['height'])
                        plate_rel_x = max(0, plate_abs_x - parent_x)
                        plate_rel_y = max(0, plate_abs_y - parent_y)
                        
                        with frame.data() as image:
                            vehicle_crop = image[parent_y:parent_y+parent_h, parent_x:parent_x+parent_w]
                            plate_crop = vehicle_crop[plate_rel_y:plate_rel_y+plate_h, plate_rel_x:plate_rel_x+plate_w]
                            if plate_crop.size > 0:
                                _, buffer = cv2.imencode('.jpg', plate_crop)
                                plate_image_b64 = base64.b64encode(buffer).decode('utf-8')
                    except Exception as e:
                        self.log.error(f"Failed to crop plate: {e}")
                else:
                    # Fallback: crop from full frame
                    try:
                        with frame.data() as image:
                            x, y, w, h = int(plate_bbox['x']), int(plate_bbox['y']), int(plate_bbox['width']), int(plate_bbox['height'])
                            if w > 0 and h > 0:
                                plate_img_crop = image[y:y+h, x:x+w]
                                _, buffer = cv2.imencode('.jpg', plate_img_crop)
                                plate_image_b64 = base64.b64encode(buffer).decode('utf-8')
                    except Exception as e:
                        self.log.error(f"Failed to crop plate (fallback): {e}")
            
            plate_obj = {
                'category': 'license_plate',
                'license_plate_text': plate_text,
                'confidence': vaobj.get('confidence'),
                'center_of_mass': vaobj.get('center_of_mass'),
                'bounding_box_px': plate_bbox,
                'object_id': vaobj.get('object_id'),
                'id': len(objects.get('license_plate', [])) + 1
            }
            if plate_image_b64:
                plate_obj['plate_image_b64'] = plate_image_b64
            
            if matched_vehicle:
                # Attach to vehicle
                matched_vehicle['license_plate'] = {
                    'text': plate_text,
                    'confidence': vaobj.get('confidence'),
                    'bounding_box_px': plate_bbox
                }
                if plate_image_b64:
                    matched_vehicle['license_plate']['image_b64'] = plate_image_b64
                    
                plate_obj['parent_vehicle_id'] = matched_vehicle.get('id')
                objects['license_plate'].append(plate_obj)
            # Skip orphan plates without matched vehicle

        self.frame_level_data['objects'] = objects

    def processFrame(self, frame):
        # Only process/publish if MQTT client is connected
        if self.client.is_connected():
            gvametadata, imgdatadict = {}, {}

            # get messages & regions from frame
            try:
                utils.get_gva_meta_messages(frame, gvametadata)
            except Exception:
                gvametadata = {}

            # prefer to populate 'objects' key — buildObjData supports legacy 'gva_meta' as fallback
            # prefer to populate 'objects' key — buildObjData supports legacy 'gva_meta' as fallback
            # MODIFICATION: Prioritize messages (from gvametaconvert) if available, as they contain full hierarchy
            # Only fall back to region extraction if no messages exist
            existing_objects = gvametadata.get('objects') or gvametadata.get('gva_meta')
            
            if not existing_objects:
                try:
                    gvametadata['objects'] = utils.get_gva_meta_regions(frame)
                except Exception:
                    gvametadata['objects'] = []
            elif gvametadata.get('gva_meta') and 'objects' not in gvametadata:
                 # Ensure 'objects' key is populated if only 'gva_meta' exists
                 gvametadata['objects'] = gvametadata['gva_meta']

            # NORMALIZE: Ensure 'label', 'confidence' and bbox are at top level
            # gvametaconvert often wraps these in a 'detection' dict
            for det in gvametadata.get('objects', []):
                # 1. Flatten 'detection' dict
                if 'detection' in det:
                    d = det['detection']
                    if 'label' not in det:
                        det['label'] = d.get('label')
                    if 'confidence' not in det:
                        det['confidence'] = d.get('confidence')
                
                # 2. Normalize geometry keys (w->width, h->height)
                if 'w' in det and 'width' not in det:
                    det['width'] = det['w']
                if 'h' in det and 'height' not in det:
                    det['height'] = det['h']
                    
                # 3. Extract object_id from tensors if missing
                if det.get('object_id') is None and 'tensors' in det:
                    for t in det['tensors']:
                        # gvatrack object_id tensor
                        if t.get('name') == 'object_id':
                            # Format could be complex, but usually it's in data or label_id?
                            # For some versions, it's just attached.
                            # If gvatrack runs, it often updates the top-level 'id' or 'label_id' not always 'object_id'
                            # But wait, looking at logs: 'id': 6 is at top level.
                            # Let's map top level 'id' to 'object_id' if object_id is missing?
                            pass
                
                # Map top level 'id' to 'object_id' if specific object_id is missing
                # This helps with ID persistence if the source provides 'id'
                if det.get('object_id') is None and det.get('id') is not None:
                     det['object_id'] = det.get('id')

            if DEBUG_MODE:
                print("GVAMETADATA (raw detections):", gvametadata.get('objects', []))

            # SMART LABEL DEFAULTING: Set fallback for SceneScape compatibility
            # SMART LABEL DEFAULTING: Set fallback for SceneScape compatibility
            # Any tracked object with no label defaults to 'vehicle' (unless model updates it later)
            for det in gvametadata.get('objects', []):
                # print("RAW DET:", det)
                if det.get('label') is None and det.get('object_id') is not None:
                    # Tracked object without label - set default for SceneScape
                    det['label'] = 'vehicle'  # Fallback - model can override with 'pedestrian'

            # build objects and publish-ready structure
            ### MODIFICATION: Pass the 'frame' object ###
            self.buildObjData(gvametadata, frame)

            # publish optional images if requested
            if self.is_publish_image:
                self.buildImgData(imgdatadict, frame, True)
                self.client.publish(f"scenescape/image/camera/{self.cameraid}", json.dumps(imgdatadict))
                self.is_publish_image = False

            if self.is_publish_calibration_image:
                if not imgdatadict:
                    self.buildImgData(imgdatadict, frame, False)
                self.client.publish(f"scenescape/image/calibration/camera/{self.cameraid}", json.dumps(imgdatadict))
                self.is_publish_calibration_image = False

            final_payload = json.dumps(self.frame_level_data)
            try:
                if DEBUG_MODE:
                    print("FINAL MQTT PAYLOAD:", json.dumps(self.frame_level_data, indent=2))
                self.client.publish(f"scenescape/data/camera/{self.cameraid}", final_payload)
            except Exception as e:
                self.log.error(f"Failed to publish to MQTT: {e}")

            # also add metadata back into frame for any downstream consumer
            try:
                frame.add_message(final_payload)
            except Exception:
                pass

        return True

